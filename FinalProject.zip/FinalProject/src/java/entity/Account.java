/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

/**
 *
 * @author Asus
 */
public class Account {

    private String userName;
    private String password;
    private String address;
    private String email;
    private String phone;
    private int role_id;
    private int status;

    public Account() {
    }

    public Account(String userName, String password, String address, String email, String phone, int role_id, int status) {
        this.userName = userName;
        this.password = password;
        this.address = address;
        this.email = email;
        this.phone = phone;
        this.role_id = role_id;
        this.status = status;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public int getRole_id() {
        return role_id;
    }

    public void setRole_id(int role_id) {
        this.role_id = role_id;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getDisplayStatus() {
        return 1 == status ? "<span style='color:green'> đang hoạt động</span>" : status == 2 ? "<span style='color:red'> Ngừng hoạt động</span>" : "tạm khóa";
    }

    public String getDisplayRole() {
        return role_id == 1 ? "Admin" : role_id == 2 ? "Staff" : "Member";
    }
}
