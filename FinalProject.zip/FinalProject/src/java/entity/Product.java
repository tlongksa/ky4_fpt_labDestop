/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.sql.Date;

/**
 *
 * @author Asus
 */
public class Product {

    private int id;
    private int category_id;
    private String code;
    private String name;
    private int quantity;
    private Double price;
    private String size;
    private String description;
    private String image;
    private Date create_date;
    private float status;
    private float sale;

    public Product() {
    }

    public Product(int id, int category_id, String code, String name, int quantity, Double price, String size, String description, String image, Date create_date, float status, float sale) {
        this.id = id;
        this.category_id = category_id;
        this.code = code;
        this.name = name;
        this.quantity = quantity;
        this.price = price;
        this.size = size;
        this.description = description;
        this.image = image;
        this.create_date = create_date;
        this.status = status;
        this.sale = sale;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCategory_id() {
        return category_id;
    }

    public void setCategory_id(int category_id) {
        this.category_id = category_id;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Date getCreate_date() {
        return create_date;
    }

    public void setCreate_date(Date create_date) {
        this.create_date = create_date;
    }

    public float getStatus() {
        return status;
    }

    public void setStatus(float status) {
        this.status = status;
    }

    public float getSale() {
        return sale;
    }

    public void setSale(float sale) {
        this.sale = sale;
    }

    

    public String getDisplayStatus() {
        return status == 1 ? "còn hàng" : status == 2 ? " giảm giá" : "ngừng kinh doanh";
    }
}
