/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.sql.Date;

/**
 *
 * @author Asus
 */
public class Order {

    private int id;
    private int customer_info_id;
    private double total_price;
    private String note;
    private Date date;
    private int status;
    private String username;

    public Order() {
    }

    public Order(int id, int customer_info_id, double total_price, String note, Date date, int status, String username) {
        this.id = id;
        this.customer_info_id = customer_info_id;
        this.total_price = total_price;
        this.note = note;
        this.date = date;
        this.status = status;
        this.username = username;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCustomer_info_id() {
        return customer_info_id;
    }

    public void setCustomer_info_id(int customer_info_id) {
        this.customer_info_id = customer_info_id;
    }

    public double getTotal_price() {
        return total_price;
    }

    public void setTotal_price(double total_price) {
        this.total_price = total_price;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getDisplayStatus() {
        return status == 1 ? "<span style='color:green'> đã xử lí</span>" : status == 2 ? "<span style='color:yellow'> đang xử lí</span>" : "<span style='color:red'> đã hủy</span>";
    }
}
