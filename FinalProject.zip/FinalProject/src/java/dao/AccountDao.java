/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.Account;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

/**
 *
 * @author Asus
 */
public class AccountDao implements ICommonDao<Account> {

    public Account GetAccount(String username, String password) {
        String sql = "select * from account where userName = ? AND password= ?";

        try (Connection con = jdbc.SQLServerConnection.getConnection(); //mở kết nối đến db
                PreparedStatement ps = (con != null) ? con.prepareStatement(sql) : null;//chuẩn bị câu query
                ) {
            ResultSet rs = null;
            if (ps != null) {
                ps.setObject(1, username);
                ps.setObject(2, password);
                rs = ps.executeQuery();
            }
            while (rs.next()) {
                Account account = new Account();
                account.setUserName(rs.getString(1));
                account.setPassword(rs.getString(2));
                account.setAddress(rs.getString(3));
                account.setEmail(rs.getString(4));
                account.setPhone(rs.getString(5));
                account.setRole_id(rs.getInt(6));
                account.setStatus(rs.getInt(7));
                return account;
            }
        } catch (Exception e) {
            e.printStackTrace(System.out);//in ra lỗi
        }
        return null;
    }

    @Override
    public List<Account> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Account getOne(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean add(Account obj) {
        String sql = "INSERT INTO [dbo].[Account]\n"
                + "           ([userName]\n"
                + "           ,[password]\n"
                + "           ,[address]\n"
                + "           ,[email]\n"
                + "           ,[phone]\n"
                + "           ,[role_id]\n"
                + "           ,[status])\n"
                + "     VALUES\n"
                + "           (?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,?\n"
                + "           ,1\n"
                + "           ,2)";
        int check = 0;
        try (Connection con = jdbc.SQLServerConnection.getConnection(); //mở kết nối đến db
                PreparedStatement ps = (con != null) ? con.prepareStatement(sql) : null;//chuẩn bị câu query
                ) {
            if (ps != null) {
                ps.setObject(1, obj.getUserName());
                ps.setObject(2, obj.getPassword());
                ps.setObject(3, obj.getAddress());
                ps.setObject(4, obj.getEmail());
                ps.setObject(5, obj.getPhone());

                check = ps.executeUpdate();
            }

        } catch (Exception e) {
            e.printStackTrace(System.out);//in ra lỗi
        }
        return check > 0;
    }

    @Override
    public boolean update(int id, Account obj) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
