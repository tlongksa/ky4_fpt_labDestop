/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.Category;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import jdbc.SQLServerConnection;

/**
 *
 * @author Asus
 */
public class CategoryDao {

    public List<Category> getAllCategory() {
        String sql = "select *from category";
        List<Category> listCategory = new ArrayList<>();
        try (Connection con = SQLServerConnection.getConnection(); //mở kết nối đến db
                PreparedStatement ps = (con != null) ? con.prepareStatement(sql) : null;//chuẩn bị câu query
                ) {
            ResultSet rs = ps.executeQuery();
            while (rs != null && rs.next()) {
                Category category = new Category();
                category.setId(rs.getInt("id"));
                category.setCategory(rs.getString("category"));
                category.setStatus(rs.getInt("status"));
                listCategory.add(category);
            }

        } catch (Exception e) {
            e.printStackTrace(System.out);
        }
        return listCategory;
    }
}
