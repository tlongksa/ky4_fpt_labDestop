/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import entity.Product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import jdbc.SQLServerConnection;

/**
 *
 * @author Asus
 */
public class ProductDao {

    public List<Product> Product() {
        String sql = "select *from product ";
        List<Product> listProduct = new ArrayList<>();
        try (Connection con = SQLServerConnection.getConnection(); //mở kết nối đến db
                PreparedStatement ps = (con != null) ? con.prepareStatement(sql) : null;//chuẩn bị câu query
                ) {
            ResultSet rs = ps.executeQuery();
            while (rs != null && rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setCategory_id(rs.getInt("category_id"));
                product.setCode(rs.getString("code"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getDouble("price"));
                product.setDescription(rs.getString("description"));
                product.setImage(rs.getString("image"));
                product.setCreate_date(rs.getDate("create_date"));
                product.setStatus(rs.getFloat("status"));
                product.setSale(rs.getFloat("sale"));
                listProduct.add(product);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }

        return listProduct;
    }

    public Product getProductByID(int id) {
        String sql = "select *from product where id=?";

        try (Connection con = SQLServerConnection.getConnection(); //mở kết nối đến db
                PreparedStatement ps = (con != null) ? con.prepareStatement(sql) : null;//chuẩn bị câu query
                ) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            while (rs != null && rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setCategory_id(rs.getInt("category_id"));
                product.setCode(rs.getString("code"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getDouble("price"));
                product.setSize(rs.getString("size"));
                product.setDescription(rs.getString("description"));
                product.setImage(rs.getString("image"));
                product.setCreate_date(rs.getDate("create_date"));
                product.setStatus(rs.getFloat("status"));
                product.setSale(rs.getFloat("sale"));
                return product;
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }

        return null;
    }

    public List<Product> getALlProduct() {
        String sql = "SELECT * FROM dbo.Product ORDER BY create_date DESC";
        List<Product> listProduct = new ArrayList<>();
        try (Connection con = SQLServerConnection.getConnection(); //mở kết nối đến db
                PreparedStatement ps = (con != null) ? con.prepareStatement(sql) : null;//chuẩn bị câu query
                ) {

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setCategory_id(rs.getInt("category_id"));
                product.setCode(rs.getString("code"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getDouble("price"));
                product.setDescription(rs.getString("description"));
                product.setCreate_date(rs.getDate("create_date"));
                product.setImage(rs.getString("image"));
                product.setStatus(rs.getFloat("status"));
                product.setSale(rs.getFloat("sale"));
                listProduct.add(product);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        return listProduct;
    }

    public List<Product> getProductbyCategoryId(int category_id) {
        String sql = "SELECT * FROM dbo.Product where category_id = ?";
        List<Product> listProduct = new ArrayList<>();
        try (Connection con = SQLServerConnection.getConnection(); //mở kết nối đến db
                PreparedStatement ps = (con != null) ? con.prepareStatement(sql) : null;//chuẩn bị câu query
                ) {
            ps.setInt(1, category_id);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setCategory_id(rs.getInt("category_id"));
                product.setCode(rs.getString("code"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getDouble("price"));
                product.setDescription(rs.getString("description"));
                product.setCreate_date(rs.getDate("create_date"));
                product.setImage(rs.getString("image"));
                product.setStatus(rs.getFloat("status"));
                product.setSale(rs.getFloat("sale"));
                listProduct.add(product);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        return listProduct;
    }

    public List<Product> Search(String txt) {
        List<Product> list = new ArrayList<>();
        String sql = "select * from product where name like N'%" + txt + "%'";
        try (Connection con = SQLServerConnection.getConnection(); //mở kết nối đến db
                PreparedStatement ps = (con != null) ? con.prepareStatement(sql) : null;//chuẩn bị câu query
                ) {
            ResultSet rs = ps.executeQuery();
            while (rs != null && rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setCategory_id(rs.getInt("category_id"));
                product.setCode(rs.getString("code"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getDouble("price"));
                product.setSize(rs.getString("size"));
                product.setDescription(rs.getString("description"));
                product.setImage(rs.getString("image"));
                product.setCreate_date(rs.getDate("create_date"));
                product.setStatus(rs.getFloat("status"));
                product.setSale(rs.getFloat("sale"));
                list.add(product);
            }
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }

        return list;
    }

    public boolean Delete(String txt) {
        try {
            String sql = "DELETE FROM dbo.product WHERE code like '%" + txt + "%'";
            List<Product> listProduct = new ArrayList<>();
            Connection con = SQLServerConnection.getConnection(); //mở kết nối đến db
            PreparedStatement ps = (con != null) ? con.prepareStatement(sql) : null;//chuẩn bị câu query
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            return false;
        }

    }

    public boolean AddProduct(Product product) {
        String sql = "INSERT [dbo].[product] ([category_id], [code], [name], [quantity], [price], [size], [description], [create_date], [status], [sale], [image]) VALUES ("+product.getCategory_id()+", N'"+product.getCode()+"', N'"+product.getName()+"', "+product.getQuantity()+", "
                +product.getPrice()+",N'"+product.getSize()+"', N'"+product.getDescription()+"', GETDATE(), '1', "+product.getSale()+","+product.getImage()+")";
        try (Connection con = SQLServerConnection.getConnection(); //mở kết nối đến db
                PreparedStatement ps = (con != null) ? con.prepareStatement(sql) : null;//chuẩn bị câu query
                ) {
            ps.executeUpdate();
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace(System.out);
        }
        return false;
    }
}
